export interface CreateNewInv {
  name: string
  dueDate: string
  inviteDate: string
  address: string
}
