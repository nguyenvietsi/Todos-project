import * as React from 'react'
import { Form, Button, Icon } from 'semantic-ui-react'
import Auth from '../auth/Auth'
import { getUploadUrl, uploadFile } from '../api/todos-api'
import '../style/InviteCard.css'



export class InviteCard extends React.PureComponent {
  render() {
    return (
      <body className="bg">
      <div className="relative">
          <div className="absolute invCard">
            <div className="absolute invPremise">THE WEDDING OF</div>
            <div className="absolute weddingName">Romeo and Juliet</div>
            <div className="absolute invName">ARE PLEASE TO INVITE YOU TO THEIR WEDDING CELEBRATION</div>
            <div className="absolute invTime">17:30 19th-OCTOBER-2023</div>
            <div className="absolute invAddr">1-1 OSAKAJO, CHUO WARD, OSAKA, 540-0002</div>
          </div>
          <div className="absolute status">
            <div className="absolute status-note">It is our pleasure to receive your wishes. If you have any photo taken with us, please upload it in the box below!</div>
            <div className="absolute status_input">
            <textarea name="postContent" rows={4} placeholder="Input your wishes..."/>
            </div>
            <div className="absolute image_add">
              <div className="upload-btn-wrapper">
                <button className="upload-btn">Upload Image</button>
                <input type="file" name="myfile" />
              </div>
            </div>
            <div className="absolute image bg-image"></div>
          </div>
          
          
      </div>
      </body>
    )
  }
}
